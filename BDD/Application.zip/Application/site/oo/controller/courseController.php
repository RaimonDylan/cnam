<?php
	include_once('../model/courseManager.php');
	$courses = getCourses();
	$include_once('../view/courseView.php');
?>
