<?php
	header('location: produit.php');
	// initialisation de la session
	// INDISPENSABLE À CETTE POSITION SI UTILISATION DES VARIABLES DE SESSION.
	session_start() ;
?>
